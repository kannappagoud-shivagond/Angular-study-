import { style } from '@angular/animations';
import { Component, OnInit } from '@angular/core';

@Component({
  // selector: 'app-servers',
  selector:'.app-servers',
   templateUrl: './servers.component.html',
 
  styleUrls: ['./servers.component.css'],
  styles:[`
  .online{
    color:white;
  }
  `]
})
export class ServersComponent implements OnInit {
  allowNewServer = false;
  serversId: number=10;
    serversStatus: string ='offline';
    serverCreationStaus = 'no server created';
     serverName= 'test serverName' 
     serverCreated=false;
     servers =['Testserver', 'TestServer 2'];

    getServersStatus(){
      return this.getServersStatus;
    }

  constructor() {
    this.serversStatus =Math.random() > 0.5 ? 'online' : 'offline';
    
    setTimeout(() => {
      this.allowNewServer = true;
    },2000);
   }

  ngOnInit(): void {
  }
  onCreateSever(){
    this.serverCreated= true;
    this.servers.push(this.serverName);
    this.serverCreationStaus='server was created! name is '+ this.serverName;
  }
  onUpdateServerName(event:any){
    console.log(event);
    // this.serverName(<HTMLInputElement>event.target).value;
  }
  getColor(){
    return this.serversStatus === 'online' ? 'green' : 'red';
  }

}
